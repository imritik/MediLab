$(function(){
    $('a[title]').tooltip();
    });
    